// Registra a Lança do Apocaralho (item custom)
// Namespace: meumodpack  |  ID: lanca  ->  meumodpack:lanca
StartupEvents.registry('item', event => {
    event.create('meumodpack:lanca', 'sword')
        .tier('netherite')            // durabilidade/nivel de mineração base
        .attackDamageBaseline(9.0)    // dano de ataque total exibido
        .speedBaseline(2.0)           // velocidade de ataque (lança = mais lenta)
        .maxStackSize(1)
        .rarity('epic')
        .displayName('Lança do Apocaralho')
        // O modelo 3D é lido automaticamente de:
        // kubejs/assets/meumodpack/models/item/lanca.json
})
