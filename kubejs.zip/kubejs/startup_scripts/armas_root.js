// Armas novas — Better Combat + Root Skills
// Namespace: meumodpack
//
//  - O estilo de ataque do Better Combat vem de kubejs/data/meumodpack/weapon_attributes/<id>.json
//  - O modelo 3D é lido de kubejs/assets/meumodpack/models/item/<id>.json
//  - A textura fica em kubejs/assets/meumodpack/textures/item/<id>.png
StartupEvents.registry('item', event => {

    // Katana: estilo "katana" do Better Combat (cortes de duas mãos).
    // Balanceada com o Bárbaro: 2 + 4 (netherita) + 1 = 7 de dano; 4 - 2.4 = 1.6 de velocidade.
    event.create('meumodpack:jade_tempest_katana', 'sword')
        .tier('netherite')
        .attackDamageBaseline(2.0)
        .speedBaseline(-2.4)
        .maxStackSize(1)
        .rarity('epic')
        .displayName('Tempestade de Jade')

    // Machado de batalha: estilo "axe" do Better Combat (machadinha de uma mão — dá pra usar
    // um em cada mão).
    // Arma do Bárbaro: a tag root_skills:greataxes liga nas skills (Esmagamento, Arremesso,
    // Rugido) e o Root Skills dá os atributos do Machado de Guerra automaticamente
    // (+7 de dano, ataque lento, +1 de alcance) — por isso não tem dano aqui.
    event.create('meumodpack:treacherous_great_axe')
        .unstackable()
        .maxDamage(700)
        .rarity('epic')
        .displayName('Machado Traiçoeiro')
        .tag('root_skills:greataxes')

    // Gloomsteel — mesma configuração das armas acima (katana / machado do Bárbaro).
    event.create('meumodpack:gloomsteel_katana', 'sword')
        .tier('netherite')
        .attackDamageBaseline(2.0)
        .speedBaseline(-2.4)
        .maxStackSize(1)
        .rarity('epic')
        .displayName('Katana de Aço Sombrio')

    event.create('meumodpack:gloomsteel_great_axe')
        .unstackable()
        .maxDamage(700)
        .rarity('epic')
        .displayName('Machado de Aço Sombrio')
        .tag('root_skills:greataxes')
})
