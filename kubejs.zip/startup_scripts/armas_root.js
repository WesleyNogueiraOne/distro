// Armas novas — Better Combat + Root Skills
// Namespace: meumodpack
//
//  - O estilo de ataque do Better Combat vem de kubejs/data/meumodpack/weapon_attributes/<id>.json
//  - O modelo 3D é lido de kubejs/assets/meumodpack/models/item/<id>.json
//  - A textura fica em kubejs/assets/meumodpack/textures/item/<id>.png
//
// Balanceamento PvP (Ladino x Samurai x Bárbaro, armadura de ferro):
//  - toda katana precisa da tag root_skills:katanas (sem ela as skills do Samurai não ativam);
//  - todo machado do Bárbaro precisa da tag root_skills:greataxes.
StartupEvents.registry('item', event => {

    // ---------------- Katanas (Samurai) ----------------
    // Estilo "katana" do Better Combat (cortes de duas mãos).
    // Dano: 0.75 + 4 (netherita) + 1 (jogador) = 5.75. Velocidade: 4 - 2.6 = 1.4 golpe/s.

    event.create('meumodpack:jade_tempest_katana', 'sword')
        .tier('netherite')
        .attackDamageBaseline(0.75)
        .speedBaseline(-2.6)
        .maxStackSize(1)
        .rarity('epic')
        .displayName('Tempestade de Jade')
        .tag('root_skills:katanas')

    event.create('meumodpack:gloomsteel_katana', 'sword')
        .tier('netherite')
        .attackDamageBaseline(0.75)
        .speedBaseline(-2.6)
        .maxStackSize(1)
        .rarity('epic')
        .displayName('Katana de Aço Sombrio')
        .tag('root_skills:katanas')

    // ---------------- Machados (Bárbaro) ----------------
    // Estilo "axe" do Better Combat (machadinha de uma mão — use um em cada mão).
    // A tag root_skills:greataxes liga nas skills (Esmagamento, Arremesso, Rugido) e o
    // Root Skills dá os atributos do Machado de Guerra automaticamente
    // (6.75 de dano, 1 golpe/s — 1.2 com um em cada mão —, +1 de alcance).
    // Por isso não tem dano aqui.

    event.create('meumodpack:treacherous_great_axe')
        .unstackable()
        .maxDamage(700)
        .rarity('epic')
        .displayName('Machado Traiçoeiro')
        .tag('root_skills:greataxes')

    event.create('meumodpack:gloomsteel_great_axe')
        .unstackable()
        .maxDamage(700)
        .rarity('epic')
        .displayName('Machado de Aço Sombrio')
        .tag('root_skills:greataxes')
})
