// Armas novas — Better Combat + Root Skills
// Namespace: meumodpack
//
//  - O estilo de ataque do Better Combat vem de kubejs/data/meumodpack/weapon_attributes/<id>.json
//  - O modelo 3D é lido de kubejs/assets/meumodpack/models/item/<id>.json
//  - A textura fica em kubejs/assets/meumodpack/textures/item/<id>.png
//
// Balanceamento PvP (Ladino x Samurai x Bárbaro, armadura de ferro):
//  - toda katana precisa da tag root_skills:katanas (sem ela as skills do Samurai não ativam);
//  - todo machado do Bárbaro precisa da tag root_skills:greataxes.
StartupEvents.registry('item', event => {

    // ---------------- Katanas (Samurai) ----------------
    // Estilo "katana" do Better Combat (cortes de duas mãos).
    // Dano: 0.75 + 4 (netherita) + 1 (jogador) = 5.75. Velocidade: 4 - 2.6 = 1.4 golpe/s.

    event.create('meumodpack:jade_tempest_katana', 'sword')
        .tier('netherite')
        .attackDamageBaseline(0.75)
        .speedBaseline(-2.6)
        .maxStackSize(1)
        .rarity('epic')
        .displayName('Tempestade de Jade')
        .tag('root_skills:katanas')

    event.create('meumodpack:gloomsteel_katana', 'sword')
        .tier('netherite')
        .attackDamageBaseline(0.75)
        .speedBaseline(-2.6)
        .maxStackSize(1)
        .rarity('epic')
        .displayName('Katana de Aço Sombrio')
        .tag('root_skills:katanas')

    // ---------------- Machados (Bárbaro) ----------------
    // Estilo "axe" do Better Combat (machadinha de uma mão — use um em cada mão).
    // A tag root_skills:greataxes liga nas skills (Esmagamento, Arremesso, Rugido) e o
    // Root Skills dá os atributos do Machado de Guerra automaticamente
    // (6.75 de dano, 1 golpe/s — 1.2 com um em cada mão —, +1 de alcance).
    // Por isso não tem dano aqui.

    event.create('meumodpack:treacherous_great_axe')
        .unstackable()
        .maxDamage(700)
        .rarity('epic')
        .displayName('Machado Traiçoeiro')
        .tag('root_skills:greataxes')

    event.create('meumodpack:gloomsteel_great_axe')
        .unstackable()
        .maxDamage(700)
        .rarity('epic')
        .displayName('Machado de Aço Sombrio')
        .tag('root_skills:greataxes')

    // ---------------- Armas pesadas (nongko's Fantasy Weapons) ----------------
    // Dano exibido = baseline + bônus do tier (ferro 2, netherita 4) + 1 (jogador).
    // Velocidade = 4 + speedBaseline.

    // Estilo "claymore" (varredura larga de duas mãos). 8 de dano, 0.9 golpe/s.
    event.create('meumodpack:grand_claymore', 'sword')
        .tier('netherite')
        .attackDamageBaseline(3)
        .speedBaseline(-3.1)
        .maxStackSize(1)
        .rarity('epic')
        .displayName('Claymore Grandiosa')

    event.create('meumodpack:black_iron_greatsword', 'sword')
        .tier('netherite')
        .attackDamageBaseline(3)
        .speedBaseline(-3.1)
        .maxStackSize(1)
        .rarity('epic')
        .displayName('Espadão de Ferro Negro')

    // Estilo "hammer" (golpes pesados de duas mãos). 9 de dano, 0.8 golpe/s.
    event.create('meumodpack:revenants_gravescepter', 'sword')
        .tier('netherite')
        .attackDamageBaseline(4)
        .speedBaseline(-3.2)
        .maxStackSize(1)
        .rarity('epic')
        .displayName('Cetro Tumular do Revenante')

    // Estilo "halberd" (duas mãos, alcance maior). 8 de dano, 0.8 golpe/s.
    event.create('meumodpack:iron_halberd', 'sword')
        .tier('iron')
        .attackDamageBaseline(5)
        .speedBaseline(-3.2)
        .maxStackSize(1)
        .rarity('rare')
        .displayName('Alabarda de Ferro')

    // Estilo "axe" (uma mão). 7 de dano, 1 golpe/s. Também corta madeira.
    event.create('meumodpack:iron_battle_axe', 'axe')
        .tier('iron')
        .attackDamageBaseline(4)
        .speedBaseline(-3.0)
        .maxStackSize(1)
        .rarity('rare')
        .displayName('Machado de Batalha de Ferro')
})
