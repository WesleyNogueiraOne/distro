// Exemplo: registrar um item simples
StartupEvents.registry('item', event => {
    event.create('meumodpack:espada_magica')
        .displayName('Espada Mágica')
        .maxStackSize(1)
})